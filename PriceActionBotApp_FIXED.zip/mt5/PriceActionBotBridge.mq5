//+------------------------------------------------------------------+
//| PriceActionBotBridge.mq5                                        |
//| Polls a VPS bridge and executes START/STOP/BUY/SELL commands.   |
//| Trading logic should be added after bridge connectivity is tested.|
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>
CTrade trade;

input string ApiURL = "http://YOUR-VPS-IP:8000/signal";
input int PollSeconds = 3;
input long Magic = 26081501;
input double DefaultLot = 0.01;
input int MaxPositions = 5;
input double DailyTargetUSD = 50.0;

string lastAction = "";
datetime lastPoll = 0;
bool botEnabled = false;

int OnInit()
{
   trade.SetExpertMagicNumber(Magic);
   EventSetTimer(MathMax(1, PollSeconds));
   Print("PriceActionBotBridge started. Add this URL to MT5 WebRequest allowed URLs: ", ApiURL);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   string json = "";
   char data[];
   char result[];
   string headers;
   ResetLastError();

   int code = WebRequest("GET", ApiURL, "", 7000, data, 0, result, headers);
   if(code != 200)
   {
      Print("Bridge WebRequest failed. HTTP=", code, " error=", GetLastError());
      return;
   }

   json = CharArrayToString(result);
   string action = JsonString(json, "action");
   string symbol = JsonString(json, "symbol");
   double lot = StringToDouble(JsonString(json, "lot"));
   if(symbol == "") symbol = _Symbol;
   if(lot <= 0) lot = DefaultLot;

   if(action == lastAction) return;
   lastAction = action;

   if(action == "start")
   {
      botEnabled = true;
      Print("BOT STARTED for ", symbol);
   }
   else if(action == "stop")
   {
      botEnabled = false;
      Print("BOT STOPPED");
   }
   else if(action == "buy" && botEnabled)
   {
      if(CountPositions(symbol) < MaxPositions)
         trade.Buy(lot, symbol, 0, 0, 0, "PA BUY");
   }
   else if(action == "sell" && botEnabled)
   {
      if(CountPositions(symbol) < MaxPositions)
         trade.Sell(lot, symbol, 0, 0, 0, "PA SELL");
   }
}

int CountPositions(string symbol)
{
   int count = 0;
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) == symbol &&
         PositionGetInteger(POSITION_MAGIC) == Magic)
         count++;
   }
   return count;
}

string JsonString(string json, string key)
{
   string needle = """ + key + "":";
   int p = StringFind(json, needle);
   if(p < 0) return "";
   p += StringLen(needle);
   while(p < StringLen(json) && (StringGetCharacter(json,p)==' ' || StringGetCharacter(json,p)=='"'))
      p++;
   int e = p;
   while(e < StringLen(json))
   {
      ushort c = StringGetCharacter(json,e);
      if(c == '"' || c == ',' || c == '}') break;
      e++;
   }
   return StringSubstr(json,p,e-p);
}
