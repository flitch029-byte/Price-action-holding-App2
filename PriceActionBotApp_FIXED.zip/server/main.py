from fastapi import FastAPI, Query
from datetime import datetime, timezone

app = FastAPI(title="Price Action Bot Bridge")
latest = {
    "action": "stop",
    "symbol": "XAUUSD",
    "lot": "0.01",
    "max_positions": "5",
    "daily_target": "50",
    "time": None,
}

@app.get("/command")
def command(
    action: str = Query(...),
    symbol: str = "XAUUSD",
    lot: str = "0.01",
    max_positions: str = "5",
    daily_target: str = "50",
):
    latest.update({
        "action": action,
        "symbol": symbol,
        "lot": lot,
        "max_positions": max_positions,
        "daily_target": daily_target,
        "time": datetime.now(timezone.utc).isoformat(),
    })
    return {"ok": True, **latest}

@app.get("/signal")
def signal():
    return {"ok": True, **latest}

@app.get("/")
def root():
    return {"service": "Price Action Bot Bridge", "status": "online"}
