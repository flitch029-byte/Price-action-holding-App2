package com.martin.priceactionbot

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var endpoint: EditText
    private lateinit var symbol: EditText
    private lateinit var lot: EditText
    private lateinit var target: EditText
    private lateinit var maxPositions: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = 20
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "🤖 PRICE ACTION BOT"
            textSize = 24f
            setPadding(0,0,0,16)
        }
        root.addView(title)

        endpoint = field(root, "VPS API URL", "http://YOUR-VPS-IP:8000")
        symbol = field(root, "Symbol", "XAUUSD")
        lot = field(root, "Lot size", "0.01")
        maxPositions = field(root, "Max positions", "5")
        target = field(root, "Daily target ($)", "50")

        val start = Button(this).apply { text = "START BOT" }
        val stop = Button(this).apply { text = "STOP BOT" }
        val buy = Button(this).apply { text = "BUY SIGNAL" }
        val sell = Button(this).apply { text = "SELL SIGNAL" }

        status = TextView(this).apply {
            text = "Status: DISCONNECTED"
            textSize = 18f
            setPadding(0,20,0,20)
        }

        root.addView(start)
        root.addView(stop)
        root.addView(buy)
        root.addView(sell)
        root.addView(status)

        start.setOnClickListener { send("start") }
        stop.setOnClickListener { send("stop") }
        buy.setOnClickListener { send("buy") }
        sell.setOnClickListener { send("sell") }

        setContentView(root)
    }

    private fun field(root: LinearLayout, hint: String, value: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine(true)
        }
        root.addView(e)
        return e
    }

    private fun send(action: String) {
        val base = endpoint.text.toString().trim().removeSuffix("/")
        if (base.isEmpty()) {
            status.text = "Status: ENTER VPS URL"
            return
        }
        status.text = "Status: SENDING $action..."
        thread {
            try {
                val query = "action=" + URLEncoder.encode(action, "UTF-8") +
                        "&symbol=" + URLEncoder.encode(symbol.text.toString(), "UTF-8") +
                        "&lot=" + URLEncoder.encode(lot.text.toString(), "UTF-8") +
                        "&max_positions=" + URLEncoder.encode(maxPositions.text.toString(), "UTF-8") +
                        "&daily_target=" + URLEncoder.encode(target.text.toString(), "UTF-8")
                val conn = URL("$base/command?$query").openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 7000
                conn.readTimeout = 7000
                val code = conn.responseCode
                val result = if (code in 200..299) "OK" else "HTTP $code"
                runOnUiThread { status.text = "Status: $result ($action)" }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Status: ERROR - ${e.message}" }
            }
        }
    }
}
