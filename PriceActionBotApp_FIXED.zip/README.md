# Price Action Bot App

This project is a starter architecture for controlling an MT5 trading EA from an Android phone.

Architecture:

Android app -> VPS Bridge API -> MT5 EA -> Broker

## Android
Enter your VPS API URL, symbol, lot, max positions and daily target.
START/STOP controls the EA state.
BUY/SELL sends manual commands.

## VPS
Run:

pip install -r server/requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000

For real deployment, protect the API with authentication/HTTPS before exposing it publicly.

## MT5
Compile `mt5/PriceActionBotBridge.mq5`.
In MT5:
Tools -> Options -> Expert Advisors -> Allow WebRequest for listed URL.
Add the exact VPS API URL.

This starter bridge deliberately separates communication from the trading strategy. Add the price-action/liquidity-sweep entry engine only after connectivity is confirmed.
